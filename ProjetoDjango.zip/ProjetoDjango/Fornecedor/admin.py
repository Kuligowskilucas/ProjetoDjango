from django.contrib import admin
from .models import Fornecedor

admin.site.register(Fornecedor)
